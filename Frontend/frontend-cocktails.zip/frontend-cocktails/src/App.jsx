import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import HomePage from './components/pages/HomePage';
import LoginPage from './components/pages/LoginPage';
import CocktailListPage from './components/pages/CocktailListPage'; 
import AboutPage from './components/pages/AboutPage'; 
import AjouterCocktailPage from './components/pages/AjouterCocktailPage'; 
import CocktailDetailsPage from './components/pages/CocktailDetailsPage';
import RegisterPage from './components/pages/RegisterPage'; 
import NotAuthorizedPage from './components/pages/NotAuthorizedPage';
import ProtectedRoute from './components/ProtectedRoute'; 
import AdminDashboard from './components/pages/AdminDashboard';
import { AuthProvider } from './components/AuthContext'; // Importer AuthProvider

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/cocktails" element={<CocktailListPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/ajouter-cocktail" element={<AjouterCocktailPage />} />
          <Route path="/cocktails/:id" element={<CocktailDetailsPage />} />
          <Route path="/register" element={<RegisterPage />} /> 
          <Route path="/not-authorized" element={<NotAuthorizedPage />} />
          <Route path="/login" element={<LoginPage />} />

          {/* Routes protégées pour l'admin */}
          <Route element={<ProtectedRoute requiredRole="admin" />}>
            <Route path="/admin-dashboard" element={<AdminDashboard />} />
          </Route>
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
