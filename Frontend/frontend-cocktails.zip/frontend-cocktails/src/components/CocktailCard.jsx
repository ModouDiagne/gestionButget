import React from 'react';
import { Card, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom'; // Importez Link

const CocktailCard = ({ cocktail }) => {
  return (
    <Card>
      <Card.Img variant="top" src={cocktail.imageUrl} />
      <Card.Body>
        <Card.Title>{cocktail.name}</Card.Title>
        <Card.Text>{cocktail.description}</Card.Text>
        <Link to={`/cocktails/${cocktail.id}`} style={{ textDecoration: 'none' }}>
          <Button variant="primary">Voir la recette</Button>
        </Link>
      </Card.Body>
    </Card>
  );
};

export default CocktailCard;
