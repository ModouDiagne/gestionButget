import React from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const AdminDashboard = () => {
  return (
    <Container className="mt-5">
      <h1 className="text-center mb-4">Tableau de Bord Administrateur</h1>
      <Row>
        <Col md={4} className="mb-4">
          <Card>
            <Card.Body>
              <Card.Title>Gérer les Cocktails</Card.Title>
              <Card.Text>
                Ajouter, modifier ou supprimer des cocktails disponibles dans la base de données.
              </Card.Text>
              <Link to="/ajouter-cocktail">
                <Button variant="primary">Ajouter un Cocktail</Button>
              </Link>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4} className="mb-4">
          <Card>
            <Card.Body>
              <Card.Title>Gérer les Utilisateurs</Card.Title>
              <Card.Text>
                Visualiser et gérer les utilisateurs enregistrés sur la plateforme.
              </Card.Text>
              <Link to="/admin/users">
                <Button variant="primary">Voir les Utilisateurs</Button>
              </Link>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4} className="mb-4">
          <Card>
            <Card.Body>
              <Card.Title>Statistiques</Card.Title>
              <Card.Text>
                Voir les statistiques globales des cocktails et des utilisateurs.
              </Card.Text>
              <Link to="/admin/stats">
                <Button variant="primary">Voir les Statistiques</Button>
              </Link>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default AdminDashboard;
