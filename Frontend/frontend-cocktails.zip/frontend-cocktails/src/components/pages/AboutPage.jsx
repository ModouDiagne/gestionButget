import React from 'react';

const AboutPage = () => {
  return (
    <div>
      <h1>À propos de Gestion des Cocktails</h1>
      <p>Cette application vous permet de gérer vos cocktails préférés.</p>
    </div>
  );
};

export default AboutPage; // Assurez-vous que c'est bien exporté par défaut
