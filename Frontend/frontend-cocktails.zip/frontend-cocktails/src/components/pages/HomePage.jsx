import React from 'react';
import NavigationBar from '../Navbar';
import HeroSection from '../HeroSection';
import CocktailList from '../CocktailList';
import Testimonials from '../Testimonials';
import Footer from '../Footer';

const HomePage = () => {
  return (
    <div>
      <NavigationBar />
      <HeroSection />
      <CocktailList />
      <Testimonials />
      <Footer />
    </div>
  );
};

export default HomePage;
