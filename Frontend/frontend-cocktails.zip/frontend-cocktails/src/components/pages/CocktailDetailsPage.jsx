import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Container, Button, Card, Row, Col } from 'react-bootstrap';

// Exemple de fonction pour récupérer les détails du cocktail
const fetchCocktailDetails = async (id) => {
  const response = await fetch(`http://localhost:8000/api/cocktails/${id}`);
  if (!response.ok) {
    throw new Error('Erreur lors de la récupération des détails du cocktail');
  }
  const data = await response.json();
  return data;
};

const CocktailDetailsPage = () => {
  const { id } = useParams(); // Récupère l'ID du cocktail depuis l'URL
  const [cocktail, setCocktail] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const getCocktailDetails = async () => {
      try {
        const data = await fetchCocktailDetails(id);
        setCocktail(data);
        setLoading(false);
      } catch (error) {
        setError(error.message);
        setLoading(false);
      }
    };

    getCocktailDetails();
  }, [id]);

  const handleEdit = () => {
    navigate(`/cocktails/${id}/edit`);
  };

  const handleDelete = async () => {
    try {
      await fetch(`http://localhost:8000/api/cocktails/${id}`, {
        method: 'DELETE',
      });
      navigate('/cocktails');
    } catch (error) {
      console.error('Erreur lors de la suppression du cocktail:', error);
      // Optionnel : Afficher une notification ou message d'erreur
    }
  };

  if (loading) return <div>Chargement...</div>;
  if (error) return <div>Erreur : {error}</div>;
  if (!cocktail) return <div>Aucun cocktail trouvé.</div>;

  return (
    <Container className="mt-5">
      <Row>
        <Col md={6}>
          <Card>
            <Card.Img variant="top" src={cocktail.imageUrl} />
            <Card.Body>
              <Card.Title>{cocktail.name}</Card.Title>
              <Card.Text>{cocktail.description}</Card.Text>
              <Card.Text>
                <strong>Instructions :</strong> {cocktail.instructions}
              </Card.Text>
              <Button variant="primary" onClick={handleEdit} className="me-2">
                Modifier
              </Button>
              <Button variant="danger" onClick={handleDelete}>
                Supprimer
              </Button>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default CocktailDetailsPage;
