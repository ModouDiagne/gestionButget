import React from 'react';
import CocktailList from '../CocktailList'; // Assurez-vous que ce chemin est correct

const CocktailListPage = () => {
  return (
    <div>
      <CocktailList />
    </div>
  );
};

export default CocktailListPage; // Assurez-vous d'avoir un export par défaut
