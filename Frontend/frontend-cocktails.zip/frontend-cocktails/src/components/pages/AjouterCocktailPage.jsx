import React from 'react';

const AjouterCocktailPage = () => {
  return (
    <div>
      <h1>Ajouter un Cocktail</h1>
      {/* Votre contenu pour ajouter un cocktail */}
    </div>
  );
};

export default AjouterCocktailPage; // Assurez-vous que c'est exporté par défaut
