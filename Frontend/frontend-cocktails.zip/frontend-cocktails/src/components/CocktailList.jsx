import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import CocktailCard from './CocktailCard';

const cocktails = [
  { id: 1, name: 'Mojito', imageUrl: 'http://example.com/mojito.jpg', description: 'Un cocktail rafraîchissant à la menthe.' },
  { id: 2, name: 'Margarita', imageUrl: 'http://example.com/margarita.jpg', description: 'Un cocktail acidulé avec du citron vert.' },
  // Ajoute plus de cocktails ici
];

const CocktailList = () => {
  return (
    <section style={{ backgroundColor: '#F9FAFB', padding: '3rem 0' }}>
      <Container>
        <h2 style={{ color: '#2C3E50', fontWeight: '700', marginBottom: '2rem', textAlign: 'center' }}>
          Explorez Nos Cocktails
        </h2>
        <Row>
          {cocktails.map(cocktail => (
            <Col key={cocktail.id} sm={12} md={6} lg={4} className="mb-4">
              <CocktailCard cocktail={cocktail} />
            </Col>
          ))}
        </Row>
      </Container>
    </section>
  );
};

export default CocktailList;
