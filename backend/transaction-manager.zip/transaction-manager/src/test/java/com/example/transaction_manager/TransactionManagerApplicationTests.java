package com.example.transaction_manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
